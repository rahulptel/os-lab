echo "Enter the length of list: "
read len
echo ${num[len]}
echo "Enter numbers: "
for((i=0;i<len;i++))
do
	read num[$i]
done
i=0
flag=0
index=0
echo "Enter required element: "
read a
while [ " $flag " -eq 0 -a " $i " -lt " $len " ]
do
	if [ " $a " -eq ${num[$i]} ] ; then
		index=$i
		flag=1;
	fi
	i=` expr $i + 1 `
done
if [ " $flag " -eq 1 ] ; then
	echo "Element found at index $index in list";
else
	echo "No such element found in the list.";
fi
