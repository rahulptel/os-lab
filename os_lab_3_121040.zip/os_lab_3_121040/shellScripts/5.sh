repeat="y"
while [ $repeat == "y" ]
do
	echo "Enter number less than 50."
	read a
	if [ "$a" -le 50 ] ; then
	{
		n=` expr $a \* $a `
		echo "Square of $a is $n. ";
	}
	else
	{
		echo "Please enter number less than fifty and greater than or equal to zero";
	}
	fi
	echo "Do you want to continue? (y/n)"
	read a	
	if [ "$a" = "n" ] ; then
		repeat="n" ;
	fi
done

