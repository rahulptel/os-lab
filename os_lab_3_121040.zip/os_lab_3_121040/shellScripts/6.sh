echo "Enter a command to be executed in the terminal :"
read cmnd
exec $cmnd
