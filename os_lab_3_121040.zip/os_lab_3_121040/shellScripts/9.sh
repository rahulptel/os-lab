flag=1
while [ " $flag " -eq 1 ]
do
	echo "What is the capital of Gujrat?"
	read reply
	if [ "$reply" = "gandhinagar" ] ; then
	{
		flag=0
		echo "correct";
	}	
	elif [ "$reply" = "Gandhinagar" ] ; then
	{
		flag=0
		echo "Bingo! You got it!";
	}
	else
	{
		echo "Sorry! Wrong answer! Try again!"
	}
	fi
done
