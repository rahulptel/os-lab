num1=0
echo $num1
num2=1
echo $num2
for((i=0;i<10;i++))
do
	temp=` expr $num1 + $num2 `
	echo $temp
	num1=$num2
	num2=$temp
done	
