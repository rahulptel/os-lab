echo "Enter month: "
read month
case "$month" in
	jan ) echo " January " ;;
	janu ) echo " January " ;;
	janua ) echo " January " ;;
	januar ) echo " January " ;;
	january ) echo " January " ;;
	*) echo "Entered month is not January." ;;
esac 
