#read the values of x and y
echo "x: "
read x
echo "y: "
read y
# keep in the mind the syntax
n1=`expr $x + $y`
n2=`expr $x - $y`
n3=`expr $x \* $y`
n4=`expr $x \/ $y`
n5=`expr $x \% $y`
# Display the result
echo "addition: $n1"
echo "subtraction: $n2"
echo "multiplication: $n3"
echo "division: $n4"
echo "Modulo: $n5"
