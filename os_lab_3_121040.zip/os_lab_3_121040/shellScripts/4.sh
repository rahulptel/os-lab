echo "a: "
read a
echo "b: "
read b
if [ " $a " -gt " $b " ] ; then
{
	echo "a is greater than b";
}
elif [ " $b " -gt " $a " ] ; then
{
	echo "b is greater than a";
}
else
{
	echo "both the values are equal";
}
fi
