x=24
y=2
echo "Value of x is 24 and y is 2"
echo "Enter expression to be performed {+, -, *, /, %}"
read z
if [ " $z " = " + " ] ; then
{
	n=` expr $x + $y `
	echo $n;
}
elif [ " $z " = " - " ] ; then
{
	n=` expr $x - $y `
	echo $n;
}
elif [ " $z " = " * " ] ; then
{
	n=` expr $x \* $y `
	echo $n;
}
elif [ " $z " = " / " ] ; then
{
	n=` expr $x \/ $y `
	echo $n;
}
elif [ " $z " = " % " ] ; then
{
	n=` expr $x \% $y `
	echo $n;
}
fi
