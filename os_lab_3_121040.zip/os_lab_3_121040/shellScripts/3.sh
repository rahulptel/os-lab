echo "a: "
read a
echo "b: "
read b
echo "expression: "
read operation
if [ " $operation " = " + " ] ; then
{
	result=` expr $a + $b `
	echo $result;
}
elif [ " $operation " = " - " ] ; then
{
	result=` expr $a - $b `
	echo $result;
}
elif [ " $operation " = " * " ] ; then
{
	result=` expr $a \* $b `
	echo $result;
}
elif [ " $operation " = " / " ] ; then
{
	result=` expr $a \/ $b `
	echo $result;
}
elif [ " $operation " = " % " ] ; then
{
	result=` expr $a \% $b `
	echo $result;
}
fi
