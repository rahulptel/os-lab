#read number
echo "Enter number upto which you want sum :"
read num
#calculate the summation upto a given number using basic calculator.
echo "($num * ($num + 1)) / 2" | bc;

