#Calculate the number of newline characters in a file
echo "Enter filename : "
read filename
#The "-n" option will not print anything unless an explicit request to print is found
sed -n '$=' "$filename"

