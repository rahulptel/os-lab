#Enter your basic salary
echo "Enter your basic salary: "
read bs
#Enter percentage of basic salary to be counted as HRA
per=0.12
echo "HRA is"
echo "$per * $bs" | bc
