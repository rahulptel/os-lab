#Read the pattern to be searched in the file
echo "Enter pattern to be searched in file: ";
read pattern;
#Read the filename in which to search
echo "Enter the name of the file: ";
read fileName;
#Use the grep command to find if the entered string is matched in the file or not
grep $pattern $fileName;
#If the pattern is matched in the file echo match else no match
if [ $? -eq 0 ]
	then              
	echo "Entered pattern is found in the file";
else
	echo "Entered pattern is not found in the file";
fi
