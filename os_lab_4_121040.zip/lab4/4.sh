#Read number
echo "Enter a number";
read num
#Find the number to be traversed to see whether is a number is prime or not
numCheck=`expr $num / 2 `;
i=2
flag=0
#Check if the entered number is 1
if [ $num == 1 ]
	then
	flag=-1
#Check if the entered number is 2
elif [ $num == 2 ]
	then 
	flag=0
#Check if the entered number is 3
elif [ $num == 3 ]
	then 
	flag=0
else
	#Check if the entered number has got a factor upto the value of number/2
	while [ "$i" -le "$numCheck" ]
	do
		remainder=`expr $num % $i `
		#If a factor is found notify the flag and exit
		if [ $remainder == 0 ]
		then
		flag=1
		break;
		fi
		i=`expr $i + 1 `
	done
fi

#Based on the value of flag decide whether the entered number is prime or not.
if [ $flag == 1 ]
	then
	echo "Entered number is not a prime number";
elif [ $flag == -1 ]
	then
	echo "1 is neither prime nor composite";
else
	echo "Entered number is prime number";
fi
