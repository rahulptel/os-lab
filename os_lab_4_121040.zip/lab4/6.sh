#Read the current hour from the system
hr=$(date +"%H")
#If the hour is greater than 0 and less than 12, display Good morning
if [ $hr -lt 12 -a $hr -ge 0 ]
	then
	echo "Good Morning !!!"
#If the hour is greater than 12 and less than 17, display Good afternoon
elif [ $hr -lt 17 -a $hr -ge 12 ]
	then
	echo "Good Afternoon!!!"
#If the hour is greater than 17 and less than 19, display Good evening
elif [ $hr -lt 20 -a $hr -ge 17 ]
	then
	echo "Good Evening!!!"
#If the hour is greater than 20 and less than 24, display Good night
else
	echo "Good Night!!!"
fi
