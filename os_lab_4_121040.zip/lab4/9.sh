#Calculate the number of spaces in a given file
#Read the filename
echo "Enter filename :"
read filename
echo "The number of spaces in the file are :"
cat $filename | tr -d '\n' | tr -s " " '\n' | wc -l
