#Enter filename
echo "Enter name of the file whose permissions you want to revoke: ";
read filename
#Check if you want to change permission or not
echo "Do you want to revoke the read, write permissions(Y/N)";
read reply
#Change the permission if the reply is Y
if [ $reply == 'y' -o $reply == 'Y' ]
	then 
	#Enter new permission
	echo "Enter new permission";
	read permission
	#Apply the permission on the given file
	chmod $permission $filename
fi
