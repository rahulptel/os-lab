#calculate the number of words
echo "Enter filename: ";
read filename
echo "The number of words are:";
cat $filename | wc -w
