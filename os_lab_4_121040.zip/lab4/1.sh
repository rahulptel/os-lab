#init flag with 1
flag=1;
#Repeat until the flag is 1. Infinite loop as we do not alter it's value.
while [ "$flag" -eq 1 ]
do
	echo Enter number smaller than 50: ;		
	#Input number	
	read num;		
	#Check if the number is less than 50							
	if [ "$num" -lt 50 ]						
	then
	{
		#Calculate the square of the number entered
		sqr=`expr $num \* $num`					
		echo Square of number $num: $sqr;
	}
	else
		#Echo the error message if the number is not less than 50
		echo "Sorry! Please enter number less than 50";
	fi
done
