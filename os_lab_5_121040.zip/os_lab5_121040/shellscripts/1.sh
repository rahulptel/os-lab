#reference: http://shellscriptinglinux.blogspot.in/2012/06/write-shell-script-to-accept-string-as.html
#to reverse a string
if [ $# -gt 0 ]  
	then
	x=`echo $1 | wc -c`
	x=`expr $x - 1`
	reverse=""
	while [ $x -gt 0 ]
		do
		c=`echo $1 | cut -c $x`
		x=`expr $x - 1`
		reverse=$reverse$c
	done
fi
echo "The reverse string is : $reverse"
