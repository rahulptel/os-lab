#Enter name of first file
echo "Enter filename 1 :"
read f1
#Enter name of second file
echo "Enter filename 2 :"
read f2
#Check if the first file exists or not
if  test -s "$f1" 
then 
    echo "First file found..."
else 
    echo "First file not found..."
fi
#Check of the second file exists or not
if  test -s "$f2" 
then 
    echo "Second file found"
    cat $f1 >> $f2
    echo "The contents of both the files have been appended..."
else 
    echo "Created new file and appended the contents..."
    touch $f2
    cat $f1 >> $f2    
fi
