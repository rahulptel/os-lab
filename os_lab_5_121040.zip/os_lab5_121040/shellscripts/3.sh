# Accept a number and a word as command line arguments and print the word the given number of times on each line.
word=$1   
number=$2
i=1;
while [ $i -le $2 ]
	do
	echo "$word"
	i=`expr $i + 1`
done

