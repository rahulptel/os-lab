#reference: http://shellscriptinglinux.blogspot.in/2012/06/write-shell-script-to-accept-alphabet.html
#Enter character
echo "Enter character :"
read char
for i in `ls -l|tr -s " "|cut -d " " -f 9`
	do
	x=`echo $i|cut -c 1`
	if [ $x = $char ]
		then echo $i
	fi
done
