#reference: http://www.dailyfreecode.com/code/shell-check-whether-given-string-1631.aspx
clear
echo "Enter a string to be entered:"   #Palindrome 
read str
echo
length=`echo $str | wc -c`
length=`expr $length - 1`
i=1
j=`expr $length / 2`
while test $i -le $j
do
k=`echo $str | cut -c $i`
l=`echo $str | cut -c $length`
if test $k != $l
then
echo "String is not palindrome..."
exit
fi
i=`expr $i + 1`
length=`expr $length - 1`
done
echo "String is palindrome..."
