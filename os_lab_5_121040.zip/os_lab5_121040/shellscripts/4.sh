#Find the file or directory with the maximum size in the current directory.
du -hsx *   
